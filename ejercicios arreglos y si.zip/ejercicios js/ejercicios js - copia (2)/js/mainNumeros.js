function calcularFactorial() {
    let num = parseInt(document.getElementById("num1").value);
    if (num < 0) {
        document.getElementById("res").innerText = "Por favor ingrese un número no negativo.";
        return;
    }
    let factorial = 1;
    let cadena = `${num}`;
    for (let i = num; i > 1; i--) {
        factorial *= i;
        cadena += ` * ${i - 1}`;
    }
    document.getElementById("res").innerText = `Resultado: ${cadena} = ${factorial}`;
}

function sumarParesC() {

  let numero = 100;
  let suma = 0;

  if (isNaN(numero) || numero < 1) {
      document.getElementById("res").innerText = "Por favor ingrese un número válido mayor que 0.";
      return;
  }

  for (let i = 1; i <= numero; i += 1) {
      suma += i;
  }
  document.getElementById("res").innerText = "La suma de los números pares hasta " + numero + " es: " + suma;
}

function sumarPares() {

  let numero = parseInt(document.getElementById("numero").value);
  let suma = 0;

  if (isNaN(numero) || numero < 1) {
      document.getElementById("res").innerText = "Por favor ingrese un número válido mayor que 0.";
      return;
  }

  for (let i = 1; i <= numero; i += 1) {
      suma += i;
  }
  document.getElementById("res").innerText = "La suma de los números pares hasta " + numero + " es: " + suma;
}

function mDiv() {

  let limite = parseInt(document.getElementById("limite").value);
  let resultado = [];

  if (isNaN(limite) || limite < 1) {
      document.getElementById("resultado").innerText = "Por favor ingrese un número válido mayor que 0.";
      return;
  }

  for (let i = 1; i <= limite; i++) {
      if (i % 3 === 0 && i % 5 === 0) {
          resultado.push(i);
      }
  }

  if (resultado.length > 0) {
      document.getElementById("res").innerText = "Números divisibles por 3 y 5 hasta " + limite + ": " + resultado.join(", ");
  } else {
      document.getElementById("res").innerText = "No hay números divisibles por 3 y 5 hasta " + limite + ".";
  }
}

function tablas() {

  let resp = "", tab = "", ini = "", fin = "", r = 0, msg = ""

  tab = document.getElementById("tabla").value

  ini = document.getElementById("vi").value

  fin = document.getElementById("vf").value

  resp = document.getElementById("resp")

  tab = parseInt(tab)
  ini = parseInt(ini)
  fin = parseInt(fin)

  while (ini <= fin) {
    
    r = ini * tab

    msg = msg + `${ini} * ${tab} = ${r}` + "\n"

    ini = ini + 1
  }
  resp.innerHTML = msg
}

function mosFibo() {

  let n = parseInt(document.getElementById("cantidad").value);
  let fibonacci = [];

  if (isNaN(n) || n <= 0) {
      document.getElementById("res").innerText = "Por favor ingrese un número válido mayor que 0.";
      return;
  }

  for (let i = 0; i < n; i++) {
      if (i === 0) {
          fibonacci.push(0);
      } else if (i === 1) {
          fibonacci.push(1);
      } else {
          fibonacci.push(fibonacci[i - 1] + fibonacci[i - 2]);
      }
  }
  document.getElementById("res").innerText = "Serie de Fibonacci: " + fibonacci.join(", ");
}

function multiplicarNumeros() {
  
  let numero1 = parseFloat(document.getElementById("numero1").value);
  let numero2 = parseFloat(document.getElementById("numero2").value);

  if (isNaN(numero1) || isNaN(numero2)) {
      document.getElementById("res").innerText = "Por favor ingrese dos números válidos.";
      return;
  }

  let resultado = numero1 * numero2;

  document.getElementById("res").innerText = "El resultado de la multiplicación es: " + resultado;
}

function calcularMultiplos(){
    let num = parseInt(document.getElementById("num1").value);
    if (num < 0 | num > 20 ) {
        document.getElementById("res").innerText = "Por favor ingrese un número valido.";
        return;
    }
    let cadena = [ ]
    let mul = 0
    for (let i = 0; i < 10; i++) {
        mul = num * i
        cadena.push(mul)
    }
    document.getElementById("res").innerText = `Resultado: ${cadena}`

}

function divisor() {

    let num1 = parseInt(document.getElementById("num1").value)
    let resultado = []
    let con = 10
    let c = 0
  
    if (num1 < 1) {
        document.getElementById("res").innerText = "Por favor ingrese un número válido mayor que 0.";
        return;
    }

    for (let i = 0; c <= con ; i+=1) {
        if (i % num1 === 0) {
          if (i == num1){
              c+=1
          } else {
            resultado.push(i);
            c+=1
          }  
        }
    }
    document.getElementById("res").innerText = `${resultado}`
}

function perfecto() {
    debugger
    let res = "", num = "", r = 0, divisor = 1, acu = 0
  
    num = document.getElementById("numero").value
    res = document.getElementById("res")
    num = parseInt(num)
  
    while (divisor < num) {
      r = num % divisor
      if (r == 0) { 
        acu = acu + divisor
      }
      divisor = divisor + 1
    }
  
    if (acu == num) {
      res.innerHTML = `${num} Es perfecto`  
    } else {
      res.innerHTML = `${num} No Es perfecto`
    }
  }

  function vPrimo() {
   
    let num = parseInt(document.getElementById("inputNumero").value);
    
    if (num <= 1) {
        document.getElementById("resultado").innerText = "Por favor ingrese un número mayor que 1.";
        return;
    }
  
    let esPrimo = true;
    for (let i = 2; i <= Math.sqrt(num); i++) {
        if (num % i === 0) {
            esPrimo = false;
            break;
        }
    }
  
    if (esPrimo) {
        document.getElementById("res").innerText = num + " es un número primo.";
    } else {
        document.getElementById("res").innerText = num + " no es un número primo.";
    }
  }
  
  function imIm() {
   let res = []
   let num = 0, conta = 0
   
   while ( conta < 50) {
    num = num + 1
    if (num % 2 > 0) {
        res.push(num)
        
    }
    conta+=1
   }
   document.getElementById("res").innerText = res
}

function invertido(){
    
    let res = "", num = "", dig = 0, msg = ""
    num = document.getElementById("num").value
    res = document.getElementById("res")
    num = parseInt(num)
  
    if (isNaN(num) || num <= 0) {
      res.innerHTML = "Por favor, ingrese un número positivo."
      return
    }

    while (num > 0) {
      dig = num % 10
      msg = msg + `${dig}`
      num = Math.trunc(num / 10)
    }
    document.getElementById("res").innerText = msg
  }

function nDDijitos(){
  let num = parseInt(document.getElementById("num").value)
  let dig = 0, conta = 0
  
  if ( num < 0){
    num = Math.abs(num)
  }
  
  while (num > 0) {
    dig = num % 10
    num = Math.trunc(num / 10)
    conta += 1
  }
  document.getElementById("res").innerText = "El numero de digitos es de " + conta 
}

function triangulo(){
  let altura = parseInt(document.getElementById("num").value)
  let obj = "", msg = "", i = 0
  if (altura <= 0){
    document.getElementById("res").innerText = "Por favor, ingrese una altura minima de 1."
      return
  }

  for (let i=0; i < altura;){
    
    obj = obj + "*"
    msg = obj
    document.getElementById("res").innerText.value = `${msg}`
    i += 1
  }
  while ( i < altura){

    
  }
}