
function NomApe() {
    var nom = document.getElementById("x1").value.trim();
    var ape = document.getElementById("x2").value.trim();
  
    if (nom && ape) {
      const r = `${nom} ${ape}`;
      document.getElementById("res").textContent = r
    } else {
      document.getElementById("res").textContent = "‼‼❔ Complete todos los campos. ‼‼⁉"
    }
  }

function comfra (){
    var fra1 = document.getElementById("x1").value
    var fra2 = document.getElementById("x2").value

    if (fra1 && fra2){
        if (fra1 > fra2){
            document.getElementById("res").innerText = `La frace ${fra1} es la mas mayor de las dos.`
        } else {
            if (fra2 > fra1){
                document.getElementById("res").innerText = "La frace " + fra2 + " es la mas mayor de las dos."
            }else{
                document.getElementById("res").innerText = "Las dos fraces son iguales."
            }
        }
    } else{
        document.getElementById("res").innerText = "Ingrese todos los valores."
    }
}

function espac(x1){
    x1 = document.getElementById("x1").value


}