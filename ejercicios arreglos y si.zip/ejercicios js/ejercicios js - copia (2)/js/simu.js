function verificarRespuesta() {
    // Obtener la opción seleccionada
     let opciones = document.getElementsByName('respuesta');
    let respuestaSeleccionada;

    for (let i = 0; i < opciones.length; i++) {
      if (opciones[i].checked) {
        respuestaSeleccionada = opciones[i].value;
        break
      }
    }

    // Verificar la respuesta
     let resultadoDiv = document.getElementById('resultado');
    if (respuestaSeleccionada === 'b') {
      resultadoDiv.textContent = "¡Correcto! Un pseudocódigo es una representación simplificada y estructurada de un algoritmo.";
      resultadoDiv.style.color = 'green'
    } else {
      resultadoDiv.textContent = "Incorrecto. La respuesta correcta es: b. Una representación simplificada y estructurada de un algoritmo.";
      resultadoDiv.style.color = 'red'
    }
  }